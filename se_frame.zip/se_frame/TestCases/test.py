#_*_coding:utf-8_*_
import os,sys
sys.path.append(os.path.split(os.getcwd())[0])
import  time,unittest,HTMLTestRunner
from PageObject.bookPage import bookPage
from PageObject.orderPage import orderPage
from PageObject.searchPage import searchPage
from Common.excelData import read_excel
from Common.function import configUrl
from selenium import  webdriver
from Common.function import  projectPath

class logingTest(unittest.TestCase):
    @classmethod
    def setUpClass(self):
        #这个path过书中出现比较多，可以放环境变量中，书里这一步省略
        path = 'E:/chromedriver.exe'
        self.driver = webdriver.Chrome(path)
        self.driver.maximize_window()

    def test_011(self):
        self.driver.get("http://39.106.127.16:8089/")

    def test_012(self):
        self.driver.get("http://39.106.127.16:8089/")

    def tearDownClass(self):
        self.driver.quit()



