from Base.base import  base
import  time
class bookPage(base):
    #预定车票
    def book(self):
        return self.by_xpath("//*[@id='tbody-01-K5260']/div[1]/div[6]/div[4]/a")

    #动车
    def book_typeD(self):
        return  self.by_css("#resultFilters01 > dl:nth-child(1) > dd.current > label > i")
    # 关闭浮层
    def book_close(self):
        return  self.by_css("#appd_wrap_close")

    def book_nologin(self):
        return  self.by_css("#btn_nologin")

    def bookBtn(self):
        try:
            time.sleep(7)
            self.book_close().click()
            time.sleep(2)
            self.book().click()
            time.sleep(2)
            self.book_nologin().click()

        except:
            self.log.error("车次查询失败")
            None
        return self.dr_url()