from Base.base import  base
import  time
class orderPage(base):
    #预定车票
    def detail_name(self):
        return self.by_css("#pasglistdiv > div > ul > li:nth-child(2) > input")



    def userInfo(self,name):
        time.sleep(5)
        self.detail_name().send_keys(name)
        time.sleep(2)
        return self.dr_url()
