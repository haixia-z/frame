from Base.base_Update import  base
from selenium.webdriver.common.by import  By
import  time
class orderPage(base):
    #预定车票
    def detail_name(self):
        return  self.findele(By.CSS_SELECTOR,"#pasglistdiv > div > ul > li:nth-child(2) > input")



    def userInfo(self,name):
        time.sleep(5)
        self.detail_name().send_keys(name)
        time.sleep(2)
