import os
import configparser
#获取项目路径
def projectPath():
    return os.path.split(os.path.realpath(__file__))[0].split('C')[0]
#返回config.ini文件中testUrl
def configUrl():
    config = configparser.ConfigParser()
    config.read(projectPath()+"config.ini")
    return  config.get('testUrl', 'url')

if __name__ == '__main__':
    print(projectPath())
    print(configUrl())